<?php

define("DEFAULT_DEV_CENTRAL", "developer");
define("DEFAULT_ENV", "sandbox");
define("DEFAULT_USER_NAME", "sdk-three_api1.sdk.com");
define("DEFAULT_PASSWORD", "QFZCWN5HZM8VBG7Q");
define("DEFAULT_SIGNATURE", "A.d9eRKfd1yVkRrtmMfCFLTqa6M9AyodL0SJkhYztxUi8W9pCXF6.4NI");
define("DEFAULT_EMAIL_ADDRESS", "sdk-seller@sdk.com");
define("DEFAULT_IDENTITY_TOKEN", "G5JgcRdmlYUwnHcYSEXI2rFuQ5yv-Ei19fMFWn30aDkZAoKt_7LTuufYXUa");
define("DEFAULT_EWP_CERT_PATH", "cert/sdk-ewp-cert.pem");
define("DEFAULT_EWP_PRIVATE_KEY_PATH", "cert/sdk-ewp-key.pem");
define("DEFAULT_EWP_PRIVATE_KEY_PWD", "password");
define("DEFAULT_CERT_ID", "KJAERUGBLVF6Y");
define("PAYPAL_CERT_PATH", "cert/sandbox-cert.pem");
define("BUTTON_IMAGE", "https://www.paypal.com/en_US/i/btn/x-click-but23.gif");
define("PAYPAL_IPN_LOG", "paypal-ipn.log");

?>